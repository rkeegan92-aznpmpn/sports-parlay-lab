import type { Candidate, Scored } from './types.ts';
import { americanToDecimal, impliedProb } from './odds.ts';

export function phi(x: number): number {
  const t = 1 / (1 + 0.2316419 * Math.abs(x)), d = 0.3989423 * Math.exp((-x * x) / 2);
  const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return x > 0 ? 1 - p : p;
}
export function poissonCdf(k: number, lambda: number): number {
  let term = Math.exp(-lambda), sum = 0;
  for (let i = 0; i <= k; i++) { sum += term; term *= lambda / (i + 1); }
  return Math.min(1, sum);
}
export const baseMarket = (m: string) => m.replace('_alternate', '');
const COUNT = new Set(['player_pass_tds', 'player_rush_attempts', 'player_receptions']);

/** Yardage: normal. Counts (receptions, attempts, pass TDs): Poisson. Anytime TD: Poisson P(X>=1). */
export function rawProbability(c: Pick<Candidate, 'market' | 'side' | 'line' | 'mean' | 'sd'>): number {
  const m = baseMarket(c.market);
  if (m === 'player_anytime_td') return 1 - Math.exp(-Math.max(c.mean, 0));
  if (c.line == null) throw new Error('Line required');
  const over = COUNT.has(m) ? 1 - poissonCdf(Math.floor(c.line), Math.max(c.mean, 1e-6)) : 1 - phi((c.line - c.mean) / Math.max(c.sd, 1e-6));
  return c.side === 'Under' ? 1 - over : over;
}
const INJURY: Record<string, number> = { Probable: 0.98, Questionable: 0.92, Doubtful: 0.5, Out: 0 };

/** Shrinks the model toward the market-implied probability when the sample is small, then applies an injury haircut. */
export function scoreCandidate(c: Candidate, now = Date.now()): Scored {
  const raw = rawProbability(c);
  const weight = c.sample / (c.sample + 6);
  let p = weight * raw + (1 - weight) * impliedProb(c.odds);
  if (c.injury) p *= INJURY[c.injury] ?? 0.92;
  const ageMin = (now - Date.parse(c.oddsAt)) / 60000;
  const stale = !(ageMin <= 30);
  const confidence = c.sample >= 9 && !c.injury && !stale ? 'High' : c.sample >= 6 ? 'Medium' : 'Low';
  return { raw, p, weight, confidence, ev: p * americanToDecimal(c.odds) - 1, stale };
}
export const scoreAll = (cs: Candidate[], now = Date.now()) => cs.map((c) => ({ ...c, scored: scoreCandidate(c, now) }));
