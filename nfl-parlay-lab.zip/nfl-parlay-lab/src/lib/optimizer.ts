import type { BuildResult, Candidate, Kind, Pos, Ticket } from './types.ts';
import { americanToDecimal, decimalToAmerican } from './odds.ts';
import { simulate } from './sim.ts';

export const SLOTS: Record<Pos, number> = { QB: 1, RB: 2, WR: 2, TE: 1 };
export const MAX_ODDS_AGE_MIN = 60;
export const MAX_LEGS_PER_GAME = 3;
export const CONFIG: Record<Kind, { minLeg: number; minSample: number; label: string }> = {
  best: { minLeg: 0.45, minSample: 4, label: 'Best Six' },
  aggr: { minLeg: 0.3, minSample: 6, label: 'Aggressive Six' },
};

/** Returns a list of problems; empty means valid. */
export function validateLegs(legs: Candidate[]): string[] {
  const errs: string[] = [];
  if (legs.length !== 6) errs.push(`Expected 6 legs, got ${legs.length}`);
  (Object.keys(SLOTS) as Pos[]).forEach((p) => {
    const n = legs.filter((l) => l.pos === p).length;
    if (n !== SLOTS[p]) errs.push(`Expected ${SLOTS[p]} ${p}, got ${n}`);
  });
  const names = legs.map((l) => `${l.name}|${l.team}`);
  if (new Set(names).size !== names.length) errs.push('Duplicate player');
  const g: Record<string, number> = {};
  legs.forEach((l) => (g[l.gameId] = (g[l.gameId] || 0) + 1));
  if (Math.max(0, ...Object.values(g)) > MAX_LEGS_PER_GAME) errs.push(`More than ${MAX_LEGS_PER_GAME} legs from one game`);
  return errs;
}
export function eligible(kind: Kind, c: Candidate, now = Date.now()): boolean {
  const s = c.scored, cfg = CONFIG[kind];
  if (!s || s.p <= 0 || c.injury === 'Out') return false;
  if (!((now - Date.parse(c.oddsAt)) / 60000 <= MAX_ODDS_AGE_MIN)) return false; // stale or unparsable odds
  if (s.p < cfg.minLeg || c.sample < cfg.minSample) return false;
  if (kind === 'aggr' && s.p < 1 / americanToDecimal(c.odds) - 0.03) return false; // unsupported long shot
  return true;
}
export function warningsFor(legs: Candidate[], now = Date.now()): string[] {
  const w: string[] = [];
  legs.forEach((l) => {
    if (l.source === 'demo') w.push(`${l.name}: Demo Data`);
    if (l.injury) w.push(`${l.name}: listed ${l.injury}`);
    if (l.scored?.stale) w.push(`${l.name}: odds ${Math.round((now - Date.parse(l.oddsAt)) / 60000)} min old`);
    if (l.sample < 6) w.push(`${l.name}: small sample (${l.sample} games)`);
  });
  const g: Record<string, number> = {};
  legs.forEach((l) => (g[l.gameId] = (g[l.gameId] || 0) + 1));
  if (Object.values(g).some((n) => n > 1)) w.push('Same-game legs: FanDuel same-game parlay availability and price are not verified.');
  return w;
}
export function makeTicket(legs: Candidate[], kind: Kind, o: { seed?: number; avoid?: Set<string>; now?: number } = {}): Ticket {
  const errs = validateLegs(legs);
  if (errs.length) throw new Error(`Invalid ticket: ${errs.join('; ')}`);
  const decimal = legs.reduce((a, l) => a * americanToDecimal(l.odds), 1);
  const indepP = legs.reduce((a, l) => a * (l.scored?.p ?? 0), 1);
  const { jointP } = simulate(legs, { seed: o.seed ?? 1 });
  const ev = jointP * decimal - 1;
  const overlap = o.avoid ? legs.filter((l) => o.avoid!.has(l.id)).length : 0;
  const score = (kind === 'best' ? jointP : ev + 0.02 * Math.log(decimal)) - (kind === 'aggr' ? 0.04 * overlap : 0);
  return { legs, decimal, american: decimalToAmerican(decimal), jointP, indepP, ev, score, warnings: warningsFor(legs, o.now) };
}
const pairs = <T,>(a: T[]) => a.flatMap((x, i) => a.slice(i + 1).map((y): [T, T] => [x, y]));

export function build(kind: Kind, pool: Candidate[], o: { now?: number; avoid?: Set<string>; top?: number } = {}): BuildResult {
  const now = o.now ?? Date.now(), rank = (c: Candidate) => (kind === 'best' ? c.scored!.p : c.scored!.ev);
  const counts: Record<Pos, number> = { QB: 0, RB: 0, WR: 0, TE: 0 };
  const best = new Map<string, Candidate>(); // one candidate per player so slots are not wasted
  for (const c of pool.filter((x) => eligible(kind, x, now))) {
    const k = `${c.name}|${c.team}`, cur = best.get(k);
    if (!cur || rank(c) > rank(cur)) best.set(k, c);
  }
  const by = (p: Pos, n: number) => [...best.values()].filter((c) => c.pos === p).sort((a, b) => rank(b) - rank(a)).slice(0, n);
  const Q = by('QB', 6), R = by('RB', 8), W = by('WR', 10), T = by('TE', 6);
  counts.QB = Q.length; counts.RB = R.length; counts.WR = W.length; counts.TE = T.length;
  const missing = (Object.keys(SLOTS) as Pos[]).filter((p) => counts[p] < SLOTS[p]).map((p) => `${SLOTS[p]} ${p} (have ${counts[p]})`);
  if (missing.length) return { options: [], missing, counts };
  const cand: { legs: Candidate[]; q: number }[] = [];
  for (const q of Q) for (const r of pairs(R)) for (const w of pairs(W)) for (const t of T) {
    const legs = [q, ...r, ...w, t];
    if (validateLegs(legs).length) continue;
    const dec = legs.reduce((a, l) => a * americanToDecimal(l.odds), 1), pi = legs.reduce((a, l) => a * l.scored!.p, 1);
    const ov = o.avoid ? legs.filter((l) => o.avoid!.has(l.id)).length : 0;
    cand.push({ legs, q: (kind === 'best' ? pi : pi * dec - 1 + 0.02 * Math.log(dec)) - (kind === 'aggr' ? 0.04 * ov : 0) });
  }
  cand.sort((a, b) => b.q - a.q);
  const options = cand.slice(0, o.top ?? 12).map((c, i) => makeTicket(c.legs, kind, { seed: 100 + i, avoid: o.avoid, now })).sort((a, b) => b.score - a.score);
  return { options, missing: options.length ? [] : ['valid combination (game cap or duplicates)'], counts };
}
/** Best Six first; Aggressive Six then avoids its players unless alternatives are clearly worse. */
export function generate(pool: Candidate[], now = Date.now()) {
  const best = build('best', pool, { now });
  const avoid = new Set(best.options[0]?.legs.map((l) => l.id) ?? []);
  return { best, aggr: build('aggr', pool, { now, avoid }) };
}
