import { normName, statOf, type StatGame } from './providers/stats.ts';
/** 1 = hit, 0 = miss, null = cannot settle safely (ambiguous match, missing stats, or push). */
export function settle(s: { player: string; opp: string; market: string; side: string; line: number | null }, games: StatGame[]): 0 | 1 | null {
  const m = games.filter((g) => normName(g.name) === normName(s.player) && g.opp === s.opp);
  if (m.length !== 1) return null; // rematches or no row: refuse to guess
  const v = statOf(m[0], s.market);
  if (s.market.replace('_alternate', '') === 'player_anytime_td') return v > 0 ? 1 : 0;
  if (s.line == null || v === s.line) return null;
  return (s.side === 'Over' ? v > s.line : v < s.line) ? 1 : 0;
}
