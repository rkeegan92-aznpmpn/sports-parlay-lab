export type Pos = 'QB' | 'RB' | 'WR' | 'TE';
export type Side = 'Over' | 'Under' | 'Yes';
export type Kind = 'best' | 'aggr';
export interface Scored { raw: number; p: number; weight: number; confidence: 'High' | 'Medium' | 'Low'; ev: number; stale: boolean }
export interface Candidate {
  id: string; name: string; pos: Pos; team: string; opp: string; gameId: string; kickoff: string;
  market: string; side: Side; line: number | null; odds: number; oddsAt: string;
  sample: number; mean: number; sd: number; injury?: string; source: 'live' | 'demo'; scored?: Scored;
}
export interface Ticket {
  legs: Candidate[]; decimal: number; american: number; jointP: number; indepP: number; ev: number; score: number; warnings: string[];
}
export interface BuildResult { options: Ticket[]; missing: string[]; counts: Record<Pos, number> }
