export function americanToDecimal(o: number): number {
  if (!Number.isFinite(o) || o === 0 || Math.abs(o) < 100) throw new RangeError(`Invalid American odds: ${o}`);
  return o > 0 ? 1 + o / 100 : 1 + 100 / Math.abs(o);
}
export function decimalToAmerican(d: number): number {
  if (!(d > 1)) throw new RangeError(`Invalid decimal odds: ${d}`);
  return d >= 2 ? Math.round((d - 1) * 100) : Math.round(-100 / (d - 1));
}
export const impliedProb = (o: number) => 1 / americanToDecimal(o);
/** Product of individual leg prices. NOT a sportsbook-confirmed same-game-parlay quote. */
export const parlayDecimal = (odds: number[]) => odds.reduce((a, o) => a * americanToDecimal(o), 1);
const r2 = (x: number) => Math.round(x * 100) / 100;
export const payout = (stake: number, decimal: number) => ({ profit: r2(stake * (decimal - 1)), total: r2(stake * decimal) });
export const fmtOdds = (o: number) => (o > 0 ? `+${Math.round(o)}` : `${Math.round(o)}`);
