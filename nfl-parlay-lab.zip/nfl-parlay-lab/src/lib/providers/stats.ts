// Player stats and injuries from nflverse (open data, no key): https://github.com/nflverse/nflverse-data
import { baseMarket } from '../model.ts';
export interface StatGame { name: string; pos: string; team: string; opp: string; season: number; week: number; v: Record<string, number> }
const NUM = ['passing_yards', 'passing_tds', 'carries', 'rushing_yards', 'receptions', 'receiving_yards', 'rushing_tds', 'receiving_tds'];

export function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = []; let field = '', row: string[] = [], q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else q = false; } else field += ch; }
    else if (ch === '"') q = true;
    else if (ch === ',') { row.push(field); field = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(field); field = ''; rows.push(row); row = []; }
    else field += ch;
  }
  if (field || row.length) { row.push(field); rows.push(row); }
  const [h, ...b] = rows;
  return b.filter((r) => r.length > 1).map((r) => Object.fromEntries(h.map((k, j) => [k, r[j] ?? ''])));
}
export const normName = (n: string) => n.toLowerCase().replace(/[.'’]/g, '').replace(/\b(jr|sr|ii|iii|iv)\b/g, '').replace(/\s+/g, ' ').trim();
export function toGames(recs: Record<string, string>[]): StatGame[] {
  return recs.filter((r) => !r.season_type || r.season_type === 'REG').map((r) => ({
    name: r.player_display_name || r.player_name, pos: r.position, team: r.team || r.recent_team, opp: r.opponent_team,
    season: Number(r.season), week: Number(r.week), v: Object.fromEntries(NUM.map((k) => [k, Number(r[k]) || 0])),
  })).filter((g) => g.name && g.team && Number.isFinite(g.week));
}
export function statOf(g: StatGame, market: string): number {
  switch (baseMarket(market)) {
    case 'player_pass_yds': return g.v.passing_yards;
    case 'player_pass_tds': return g.v.passing_tds;
    case 'player_rush_yds': return g.v.rushing_yards;
    case 'player_rush_attempts': return g.v.carries;
    case 'player_reception_yds': return g.v.receiving_yards;
    case 'player_receptions': return g.v.receptions;
    case 'player_anytime_td': return g.v.rushing_tds + g.v.receiving_tds;
    default: throw new Error(`Unsupported market ${market}`);
  }
}
const avg = (a: number[]) => a.reduce((x, y) => x + y, 0) / a.length;
/** Weighted blend of last-3/5/10 means times an opponent factor. Returns null when no games exist. */
export function project(games: StatGame[], market: string, oppFactor = 1) {
  const v = [...games].sort((a, b) => a.season - b.season || a.week - b.week).map((g) => statOf(g, market));
  if (!v.length) return null;
  const last = (n: number) => avg(v.slice(-n));
  const mean = (0.3 * last(3) + 0.3 * last(5) + 0.4 * last(10)) * oppFactor;
  const w = v.slice(-10), m = avg(w), sd = Math.sqrt(avg(w.map((x) => (x - m) ** 2)));
  return { mean, sd: Math.max(sd, 0.2 * mean, 0.5), sample: v.length };
}
/** Opponent defense vs position: avg stat allowed relative to league average, shrunk 50% and clamped to 0.85-1.15. */
export function oppFactor(all: StatGame[], opp: string, pos: string, market: string): number {
  const per = new Map<string, number>();
  for (const g of all.filter((x) => x.pos === pos)) { const k = `${g.opp}|${g.week}`; per.set(k, (per.get(k) ?? 0) + statOf(g, market)); }
  const byOpp = new Map<string, number[]>();
  for (const [k, v] of per) { const o = k.split('|')[0]; byOpp.set(o, [...(byOpp.get(o) ?? []), v]); }
  const league = avg([...per.values()]), mine = byOpp.get(opp);
  if (!mine || !league) return 1;
  return Math.min(1.15, Math.max(0.85, 1 + 0.5 * (avg(mine) / league - 1)));
}
export async function fetchText(url: string, f: typeof fetch = fetch): Promise<string> {
  const res = await f(url, { redirect: 'follow' });
  if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
  return res.text();
}
export const statsUrl = (season: number) => (process.env.NFL_STATS_URL ?? 'https://github.com/nflverse/nflverse-data/releases/download/stats_player/stats_player_week_{season}.csv').replace('{season}', String(season));
export const injuriesUrl = (season: number) => (process.env.NFL_INJURIES_URL ?? 'https://github.com/nflverse/nflverse-data/releases/download/injuries/injuries_{season}.csv').replace('{season}', String(season));
export async function loadStats(season: number, f: typeof fetch = fetch) { return toGames(parseCsv(await fetchText(statsUrl(season), f))); }
/** Latest-week report status per player. Missing file => empty map (flagged by caller, never guessed). */
export async function loadInjuries(season: number, f: typeof fetch = fetch): Promise<Map<string, string>> {
  const out = new Map<string, { w: number; s: string }>();
  for (const r of parseCsv(await fetchText(injuriesUrl(season), f))) {
    const n = normName(r.full_name || ''), w = Number(r.week), s = r.report_status;
    if (!n || !s) continue;
    const cur = out.get(n); if (!cur || w >= cur.w) out.set(n, { w, s });
  }
  return new Map([...out].map(([k, v]) => [k, v.s]));
}
