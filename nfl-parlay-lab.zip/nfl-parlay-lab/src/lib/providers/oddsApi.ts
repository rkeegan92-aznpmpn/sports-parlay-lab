// The Odds API v4. Docs: https://the-odds-api.com/liveapi/guides/v4/
export const BASE = 'https://api.the-odds-api.com/v4';
export const SPORT = 'americanfootball_nfl';
export const BOOKMAKER = 'fanduel';
export const DEFAULT_MARKETS = [
  'player_pass_yds', 'player_pass_tds', 'player_rush_yds', 'player_rush_attempts', 'player_reception_yds', 'player_receptions', 'player_anytime_td',
  'player_pass_yds_alternate', 'player_rush_yds_alternate', 'player_reception_yds_alternate', 'player_receptions_alternate',
];
export class OddsApiError extends Error {
  status: number;
  constructor(message: string, status: number) { super(message); this.name = 'OddsApiError'; this.status = status; }
}
export interface ApiEvent { id: string; commence_time: string; home_team: string; away_team: string }
export interface PropRow { player: string; market: string; side: 'Over' | 'Under' | 'Yes'; line: number | null; odds: number; updatedAt: string }
type Fetch = typeof fetch;

async function get(path: string, params: Record<string, string>, key: string, f: Fetch) {
  const url = `${BASE}${path}?${new URLSearchParams({ ...params, apiKey: key })}`;
  let res: Response;
  try { res = await f(url); } catch (e) { throw new OddsApiError(`Network error: ${(e as Error).message}`, 0); }
  if (!res.ok) {
    const why = res.status === 401 ? 'Invalid API key' : res.status === 422 ? 'Market or parameters not available on your plan' : res.status === 429 ? 'Rate or quota limit reached' : `HTTP ${res.status}`;
    throw new OddsApiError(why, res.status);
  }
  let data: unknown;
  try { data = await res.json(); } catch { throw new OddsApiError('Malformed JSON from Odds API', res.status); }
  return { data, remaining: res.headers?.get?.('x-requests-remaining') ?? null };
}
export async function fetchEvents(key: string, f: Fetch = fetch) {
  const r = await get(`/sports/${SPORT}/events`, {}, key, f);
  if (!Array.isArray(r.data)) throw new OddsApiError('Unexpected events response', 200);
  return { events: r.data as ApiEvent[], remaining: r.remaining };
}
export async function fetchEventProps(key: string, eventId: string, markets: string[] = DEFAULT_MARKETS, f: Fetch = fetch) {
  const r = await get(`/sports/${SPORT}/events/${eventId}/odds`, { regions: 'us', markets: markets.join(','), bookmakers: BOOKMAKER, oddsFormat: 'american' }, key, f);
  return { rows: parseProps(r.data), remaining: r.remaining };
}
/** Keeps FanDuel only; silently drops malformed outcomes rather than guessing. */
export function parseProps(json: any): PropRow[] {
  const rows: PropRow[] = [];
  for (const b of json?.bookmakers ?? []) {
    if (b.key !== BOOKMAKER) continue;
    for (const m of b.markets ?? []) for (const o of m.outcomes ?? []) {
      const side = o.name;
      if (!['Over', 'Under', 'Yes'].includes(side) || typeof o.price !== 'number' || !o.description) continue;
      rows.push({ player: o.description, market: m.key, side, line: typeof o.point === 'number' ? o.point : null, odds: o.price, updatedAt: m.last_update ?? b.last_update });
    }
  }
  return rows;
}
