import type { Candidate } from './types.ts';
import { phi } from './model.ts';

function rng(seed: number) {
  let s = seed | 0;
  return () => { s = (s + 0x6d2b79f5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const normal = (r: () => number) => Math.sqrt(-2 * Math.log(r() || 1e-12)) * Math.cos(2 * Math.PI * r());

/** Gaussian-copula Monte Carlo: legs share team and game factors. Loadings are assumptions, not fitted values. */
export function simulate(legs: Candidate[], o: { n?: number; seed?: number; teamLoad?: number; gameLoad?: number } = {}) {
  const n = o.n ?? 6000, A = o.teamLoad ?? 0.3, B = o.gameLoad ?? 0.12;
  if (A * A + B * B >= 1) throw new RangeError('Loadings too large');
  const r = rng(o.seed ?? 1), idio = Math.sqrt(1 - A * A - B * B);
  let hits = 0;
  for (let i = 0; i < n; i++) {
    const gt: Record<string, number> = {}, gg: Record<string, number> = {};
    let ok = true;
    for (const l of legs) {
      gt[l.team] ??= normal(r); gg[l.gameId] ??= normal(r);
      const z = A * gt[l.team] + B * gg[l.gameId] + idio * normal(r);
      if (phi(z) >= (l.scored?.p ?? 0)) ok = false;
    }
    if (ok) hits++;
  }
  const jointP = hits / n;
  return { jointP, se: Math.sqrt((jointP * (1 - jointP)) / n) };
}
