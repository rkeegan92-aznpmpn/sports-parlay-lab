import { americanToDecimal } from './odds.ts';
export interface Row { pos: string; market: string; side: string; line: number | null; odds: number; p: number; hit: 0 | 1; snapshotTs: number; kickoffTs: number; ticketId?: string }
const pct = (a: number) => Math.round(a * 1000) / 10;
const roi = (a: Row[]) => (a.length ? pct(a.reduce((s, r) => s + (r.hit ? americanToDecimal(r.odds) - 1 : -1), 0) / a.length) : null);
function group(rows: Row[], f: (r: Row) => string) {
  const m: Record<string, Row[]> = {}; rows.forEach((r) => (m[f(r)] ??= []).push(r));
  return Object.fromEntries(Object.entries(m).map(([k, a]) => [k, { n: a.length, hitRate: pct(a.filter((r) => r.hit).length / a.length), roiPct: roi(a) }]));
}
/** Rows whose snapshot is not strictly before kickoff are rejected, so post-start information cannot leak in. */
export function report(input: Row[]) {
  const rows = input.filter((r) => r.snapshotTs < r.kickoffTs && r.p >= 0 && r.p <= 1 && (r.hit === 0 || r.hit === 1) && Number.isFinite(r.odds) && Math.abs(r.odds) >= 100);
  const E = [0, 0.3, 0.4, 0.5, 0.6, 0.7, 1.01];
  const calibration = E.slice(0, -1).map((lo, i) => { const a = rows.filter((r) => r.p >= lo && r.p < E[i + 1]); return a.length ? { bin: `${Math.round(lo * 100)}-${Math.min(100, Math.round(E[i + 1] * 100))}%`, n: a.length, predicted: pct(a.reduce((s, r) => s + r.p, 0) / a.length), actual: pct(a.filter((r) => r.hit).length / a.length) } : null; }).filter(Boolean);
  const t: Record<string, Row[]> = {}; rows.forEach((r) => r.ticketId && (t[r.ticketId] ??= []).push(r));
  const full = Object.values(t).filter((a) => a.length === 6);
  const wins = full.filter((a) => a.every((r) => r.hit)).length;
  const parlayRoi = full.length ? pct(full.reduce((s, a) => s + (a.every((r) => r.hit) ? a.reduce((p, r) => p * americanToDecimal(r.odds), 1) - 1 : -1), 0) / full.length) : null;
  return { n: rows.length, rejected: input.length - rows.length, legHitRate: rows.length ? pct(rows.filter((r) => r.hit).length / rows.length) : null, legRoiPct: roi(rows),
    parlays: { n: full.length, hits: wins, roiPct: parlayRoi }, byPosition: group(rows, (r) => r.pos), byMarket: group(rows, (r) => r.market), calibration,
    note: 'Small samples say little about profitability. No profit claim is made.' };
}
