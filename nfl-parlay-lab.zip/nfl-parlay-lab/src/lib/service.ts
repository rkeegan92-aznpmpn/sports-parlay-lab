import type { Candidate, Pos } from './types.ts';
import { scoreAll } from './model.ts';
import { fetchEventProps, fetchEvents, DEFAULT_MARKETS } from './providers/oddsApi.ts';
import { loadInjuries, loadStats, normName, oppFactor, project } from './providers/stats.ts';

export interface LoadResult { mode: 'live' | 'demo'; notes: string[]; candidates: Candidate[]; games: { id: string; label: string }[]; diagnostics: Record<string, number | string> }
export const TEAM_ABBR: Record<string, string> = {
  'Arizona Cardinals': 'ARI', 'Atlanta Falcons': 'ATL', 'Baltimore Ravens': 'BAL', 'Buffalo Bills': 'BUF', 'Carolina Panthers': 'CAR', 'Chicago Bears': 'CHI',
  'Cincinnati Bengals': 'CIN', 'Cleveland Browns': 'CLE', 'Dallas Cowboys': 'DAL', 'Denver Broncos': 'DEN', 'Detroit Lions': 'DET', 'Green Bay Packers': 'GB',
  'Houston Texans': 'HOU', 'Indianapolis Colts': 'IND', 'Jacksonville Jaguars': 'JAX', 'Kansas City Chiefs': 'KC', 'Las Vegas Raiders': 'LV', 'Los Angeles Chargers': 'LAC',
  'Los Angeles Rams': 'LA', 'Miami Dolphins': 'MIA', 'Minnesota Vikings': 'MIN', 'New England Patriots': 'NE', 'New Orleans Saints': 'NO', 'New York Giants': 'NYG',
  'New York Jets': 'NYJ', 'Philadelphia Eagles': 'PHI', 'Pittsburgh Steelers': 'PIT', 'San Francisco 49ers': 'SF', 'Seattle Seahawks': 'SEA', 'Tampa Bay Buccaneers': 'TB',
  'Tennessee Titans': 'TEN', 'Washington Commanders': 'WAS',
};
export const currentSeason = (d = new Date()) => (d.getUTCMonth() <= 1 ? d.getUTCFullYear() - 1 : d.getUTCFullYear());
const POS_OK: Record<string, Pos[]> = { player_pass_yds: ['QB'], player_pass_tds: ['QB'], player_rush_yds: ['RB', 'QB'], player_rush_attempts: ['RB'], player_reception_yds: ['WR', 'TE', 'RB'], player_receptions: ['WR', 'TE', 'RB'], player_anytime_td: ['QB', 'RB', 'WR', 'TE'] };
const SLOT_POS = new Set(['QB', 'RB', 'WR', 'TE']);

export async function loadLive(o: { key: string; maxEvents?: number; markets?: string[] }, now = Date.now(), f: typeof fetch = fetch): Promise<LoadResult> {
  const season = currentSeason(new Date(now)), notes: string[] = [];
  const { events } = await fetchEvents(o.key, f);
  const games = await loadStats(season, f);
  let inj = new Map<string, string>();
  try { inj = await loadInjuries(season, f); } catch (e) { notes.push(`Injury data unavailable (${(e as Error).message}). Injury status is unknown, not "healthy".`); }
  const byName = new Map<string, typeof games>();
  for (const g of games) { const k = normName(g.name); byName.set(k, [...(byName.get(k) ?? []), g]); }
  const d: Record<string, number> = { eventsScanned: 0, propsSeen: 0, candidates: 0, noStats: 0, teamMismatch: 0 };
  const candidates: Candidate[] = [], gl: { id: string; label: string }[] = [];
  let remaining: string | null = null;
  for (const ev of events.slice(0, o.maxEvents ?? 16)) {
    const home = TEAM_ABBR[ev.home_team], away = TEAM_ABBR[ev.away_team];
    if (!home || !away) { notes.push(`Unknown team name in ${ev.away_team} @ ${ev.home_team}; skipped.`); continue; }
    let rows; try { const r = await fetchEventProps(o.key, ev.id, o.markets ?? DEFAULT_MARKETS, f); rows = r.rows; remaining = r.remaining; }
    catch (e) { notes.push(`${away} @ ${home}: ${(e as Error).message}`); continue; }
    d.eventsScanned++; gl.push({ id: ev.id, label: `${away} @ ${home}` });
    for (const r of rows) {
      d.propsSeen++;
      const pg = byName.get(normName(r.player));
      if (!pg) { d.noStats++; continue; }
      const last = [...pg].sort((a, b) => a.season - b.season || a.week - b.week).at(-1)!;
      if (![home, away].includes(last.team) || !SLOT_POS.has(last.pos) || !(POS_OK[r.market.replace('_alternate', '')] ?? []).includes(last.pos as Pos)) { d.teamMismatch++; continue; }
      const opp = last.team === home ? away : home;
      const p = project(pg, r.market, oppFactor(games, opp, last.pos, r.market));
      if (!p || r.line == null && r.side !== 'Yes') continue;
      const status = inj.get(normName(r.player));
      candidates.push({ id: `${ev.id}:${r.player}:${r.market}:${r.side}:${r.line}`, name: r.player, pos: last.pos as Pos, team: last.team, opp, gameId: ev.id, kickoff: ev.commence_time,
        market: r.market, side: r.side, line: r.line, odds: r.odds, oddsAt: r.updatedAt, sample: p.sample, mean: p.mean, sd: p.sd, injury: status && /out|doubtful|questionable|probable/i.test(status) ? status : undefined, source: 'live' });
      d.candidates++;
    }
  }
  notes.push('Not yet modeled: weather, routes/target share, game script, home/away split, comparable-opponent history.');
  return { mode: 'live', notes, candidates: scoreAll(candidates, now), games: gl, diagnostics: { ...d, oddsApiCreditsRemaining: remaining ?? 'unknown' } };
}

const DEMO: [string, string, Pos, string, string, string, string, string, number, number, number, number, number, string, number][] = [
  ['q1', 'Marcus Vale', 'QB', 'AAA', 'BBB', 'G1', 'player_pass_yds', 'Over', 262.5, -114, 278, 52, 10, '', 4],
  ['q2', 'Dre Kowalski', 'QB', 'CCC', 'DDD', 'G2', 'player_pass_tds', 'Over', 1.5, -135, 1.9, 0.9, 9, '', 6],
  ['q3', 'Eli Strand', 'QB', 'EEE', 'FFF', 'G3', 'player_pass_yds', 'Over', 289.5, 105, 297, 58, 3, '', 90],
  ['r1', 'Jalen Okoro', 'RB', 'AAA', 'BBB', 'G1', 'player_rush_yds', 'Over', 68.5, -110, 74, 24, 10, '', 4],
  ['r2', 'Tre Mabry', 'RB', 'CCC', 'DDD', 'G2', 'player_anytime_td', 'Yes', 0, 110, 0.62, 0, 10, '', 6],
  ['r3', 'Colt Ferris', 'RB', 'BBB', 'AAA', 'G1', 'player_rush_yds', 'Over', 54.5, -105, 58, 22, 9, 'Questionable', 5],
  ['r4', 'Nico Barlow', 'RB', 'EEE', 'FFF', 'G3', 'player_rush_attempts', 'Over', 17.5, -120, 18.4, 3.6, 10, '', 8],
  ['r5', 'Wes Tolliver', 'RB', 'DDD', 'CCC', 'G2', 'player_rush_yds', 'Over', 79.5, 120, 76, 26, 7, '', 6],
  ['w1', 'Amari Fenn', 'WR', 'AAA', 'BBB', 'G1', 'player_reception_yds', 'Over', 74.5, -110, 81, 26, 10, '', 4],
  ['w2', 'Devon Pike', 'WR', 'CCC', 'DDD', 'G2', 'player_receptions', 'Over', 5.5, -125, 6.1, 1.9, 10, '', 6],
  ['w3', 'Zane Holt', 'WR', 'BBB', 'AAA', 'G1', 'player_reception_yds', 'Over', 62.5, -105, 64, 24, 8, '', 5],
  ['w4', 'Rico Dane', 'WR', 'EEE', 'FFF', 'G3', 'player_reception_yds', 'Over', 88.5, 125, 86, 30, 10, '', 8],
  ['w5', 'Cal Ibarra', 'WR', 'DDD', 'CCC', 'G2', 'player_anytime_td', 'Yes', 0, 150, 0.46, 0, 10, '', 6],
  ['t1', 'Owen Sutter', 'TE', 'AAA', 'BBB', 'G1', 'player_reception_yds', 'Over', 48.5, -115, 52, 19, 10, '', 4],
  ['t2', 'Gabe Lindqvist', 'TE', 'EEE', 'FFF', 'G3', 'player_receptions', 'Over', 4.5, -130, 4.9, 1.6, 6, '', 8],
  ['t3', 'Max Rowan', 'TE', 'CCC', 'DDD', 'G2', 'player_anytime_td', 'Yes', 0, 190, 0.38, 0, 10, '', 6],
];
/** Fictional players and illustrative odds. Always labeled Demo Data. */
export function demoResult(now = Date.now(), reason = ''): LoadResult {
  const cs: Candidate[] = DEMO.map((a) => ({ id: a[0], name: a[1], pos: a[2], team: a[3], opp: a[4], gameId: a[5], kickoff: new Date(now + 864e5).toISOString(), market: a[6], side: a[7] as Candidate['side'],
    line: a[6] === 'player_anytime_td' ? null : a[8], odds: a[9], oddsAt: new Date(now - a[14] * 60000).toISOString(), sample: a[12], mean: a[10], sd: a[11], injury: a[13] || undefined, source: 'demo' }));
  return { mode: 'demo', notes: [`${reason} Showing Demo Data (fictional players, illustrative odds).`.trim()], candidates: scoreAll(cs, now),
    games: [{ id: 'G1', label: 'AAA vs BBB' }, { id: 'G2', label: 'CCC vs DDD' }, { id: 'G3', label: 'EEE vs FFF' }], diagnostics: {} };
}
