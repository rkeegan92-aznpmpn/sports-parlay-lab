import { getDb } from './db.ts';
import { demoResult, loadLive, currentSeason, type LoadResult } from '../lib/service.ts';
import { scoreAll } from '../lib/model.ts';

export async function getData(force = false): Promise<LoadResult> {
  const now = Date.now(), key = process.env.ODDS_API_KEY;
  if (!key) return demoResult(now, 'ODDS_API_KEY is not set.');
  const db = getDb(), ttl = Number(process.env.ODDS_CACHE_MIN ?? 10) * 60000;
  if (!force) {
    const row = db.prepare('SELECT value, fetched_at FROM cache WHERE key = ?').get('live') as { value: string; fetched_at: number } | undefined;
    if (row && now - row.fetched_at < ttl) { const r = JSON.parse(row.value) as LoadResult; r.candidates = scoreAll(r.candidates, now); return r; }
  }
  try {
    const r = await loadLive({ key, maxEvents: Number(process.env.MAX_EVENTS ?? 16) }, now);
    db.prepare('INSERT OR REPLACE INTO cache (key, value, fetched_at) VALUES (?, ?, ?)').run('live', JSON.stringify(r), now);
    const ins = db.prepare('INSERT OR REPLACE INTO snapshots (snapshot_ts, kickoff_ts, season, player, team, opp, pos, market, side, line, odds, p) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
    const season = currentSeason(new Date(now));
    db.transaction(() => { for (const c of r.candidates) { const ko = Date.parse(c.kickoff); if (ko > now && c.scored) ins.run(now, ko, season, c.name, c.team, c.opp, c.pos, c.market, c.side, c.line ?? 0, c.odds, c.scored.p); } })();
    return r;
  } catch (e) {
    return demoResult(now, `Live data unavailable: ${(e as Error).message}.`);
  }
}
