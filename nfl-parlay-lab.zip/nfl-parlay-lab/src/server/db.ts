import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
export const SCHEMA = `
CREATE TABLE IF NOT EXISTS saved_tickets (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, created_at INTEGER NOT NULL, source TEXT NOT NULL, joint_p REAL, decimal REAL, legs_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS snapshots (id INTEGER PRIMARY KEY AUTOINCREMENT, snapshot_ts INTEGER NOT NULL, kickoff_ts INTEGER NOT NULL, season INTEGER, player TEXT NOT NULL, team TEXT, opp TEXT, pos TEXT, market TEXT NOT NULL, side TEXT NOT NULL, line REAL, odds INTEGER NOT NULL, p REAL NOT NULL, hit INTEGER, UNIQUE(player, market, side, line, kickoff_ts));
CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT NOT NULL, fetched_at INTEGER NOT NULL);`;
let db: Database.Database | undefined;
export function getDb() {
  if (!db) {
    const file = process.env.DB_PATH ?? './data/parlay.db';
    fs.mkdirSync(path.dirname(file), { recursive: true });
    db = new Database(file); db.pragma('journal_mode = WAL'); db.exec(SCHEMA);
  }
  return db;
}
