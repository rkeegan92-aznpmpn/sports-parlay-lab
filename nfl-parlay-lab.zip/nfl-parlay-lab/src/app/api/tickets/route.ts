import { NextResponse } from 'next/server';
import { getData } from '@/server/load.ts';
import { generate, eligible } from '@/lib/optimizer.ts';

export const dynamic = 'force-dynamic';
export async function GET(req: Request) {
  const u = new URL(req.url), game = u.searchParams.get('game') ?? 'ALL', now = Date.now();
  const data = await getData(u.searchParams.get('refresh') === '1');
  const pool = data.candidates.filter((c) => game === 'ALL' || c.gameId === game);
  const g = generate(pool, now);
  const used = pool.filter((c) => eligible('best', c, now) || eligible('aggr', c, now));
  const stale = pool.filter((c) => c.scored?.stale).length;
  return NextResponse.json({ mode: data.mode, notes: data.notes, games: data.games, diagnostics: data.diagnostics, scanned: pool.length, staleCount: stale, pool: used, ...g, generatedAt: now });
}
