import { NextResponse } from 'next/server';
import { getDb } from '@/server/db.ts';
export const dynamic = 'force-dynamic';
export async function GET() {
  const rows = getDb().prepare('SELECT id, kind, created_at, source, joint_p, decimal, legs_json FROM saved_tickets ORDER BY id DESC LIMIT 50').all();
  return NextResponse.json(rows);
}
export async function POST(req: Request) {
  const b = await req.json().catch(() => null);
  if (!b || !['best', 'aggr'].includes(b.kind) || !Array.isArray(b.legs) || b.legs.length !== 6) return NextResponse.json({ error: 'Invalid ticket' }, { status: 400 });
  const r = getDb().prepare('INSERT INTO saved_tickets (kind, created_at, source, joint_p, decimal, legs_json) VALUES (?,?,?,?,?,?)').run(b.kind, Date.now(), b.legs[0]?.source ?? 'unknown', b.jointP, b.decimal, JSON.stringify(b.legs));
  return NextResponse.json({ id: Number(r.lastInsertRowid) });
}
