import { NextResponse } from 'next/server';
import { getDb } from '@/server/db.ts';
import { report, type Row } from '@/lib/backtest.ts';
import { loadStats } from '@/lib/providers/stats.ts';
import { settle } from '@/lib/settle.ts';
import { currentSeason } from '@/lib/service.ts';
export const dynamic = 'force-dynamic';
/** Settles finished snapshots from nflverse stats (unambiguous matches only), then reports on settled rows. */
export async function GET() {
  const db = getDb(), now = Date.now(), notes: string[] = [];
  const open = db.prepare('SELECT id, player, opp, market, side, line FROM snapshots WHERE hit IS NULL AND kickoff_ts < ?').all(now - 6 * 3600e3) as any[];
  if (open.length) {
    try {
      const games = await loadStats(currentSeason());
      const upd = db.prepare('UPDATE snapshots SET hit = ? WHERE id = ?');
      db.transaction(() => { for (const s of open) { const h = settle({ ...s, line: s.market.includes('anytime') ? null : s.line }, games); if (h !== null) upd.run(h, s.id); } })();
    } catch (e) { notes.push(`Settlement skipped: ${(e as Error).message}`); }
  }
  const rows = db.prepare('SELECT pos, market, side, line, odds, p, hit, snapshot_ts AS snapshotTs, kickoff_ts AS kickoffTs FROM snapshots WHERE hit IS NOT NULL').all() as Row[];
  return NextResponse.json({ ...report(rows), unsettled: open.length, notes });
}
