import { NextResponse } from 'next/server';
export const dynamic = 'force-dynamic';
export async function GET() {
  return NextResponse.json({ oddsApiKeyConfigured: Boolean(process.env.ODDS_API_KEY), mode: process.env.ODDS_API_KEY ? 'live' : 'demo' });
}
