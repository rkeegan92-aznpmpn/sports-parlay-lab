'use client';
import { useCallback, useEffect, useState } from 'react';
import type { BuildResult, Candidate, Kind, Ticket } from '@/lib/types.ts';
import { eligible, makeTicket, CONFIG } from '@/lib/optimizer.ts';
import { fmtOdds, payout } from '@/lib/odds.ts';

interface Data { mode: 'live' | 'demo'; notes: string[]; games: { id: string; label: string }[]; scanned: number; staleCount: number; pool: Candidate[]; best: BuildResult; aggr: BuildResult }
const KINDS: Kind[] = ['best', 'aggr'];
const pc = (x: number, d = 1) => `${(x * 100).toFixed(d)}%`;
const label = (c: Candidate) => (c.market.replace('player_', '').replace(/_/g, ' ')) + (c.line == null ? '' : ` ${c.side} ${c.line}`);

export default function Home() {
  const [data, setData] = useState<Data | null>(null);
  const [game, setGame] = useState('ALL');
  const [idx, setIdx] = useState<Record<Kind, number>>({ best: 0, aggr: 0 });
  const [edit, setEdit] = useState<Partial<Record<Kind, Ticket>>>({});
  const [err, setErr] = useState('');
  const [saved, setSaved] = useState(0);
  const [bt, setBt] = useState<any>(null);

  const load = useCallback(async (refresh = false) => {
    setErr('');
    try {
      const r = await fetch(`/api/tickets?game=${game}${refresh ? '&refresh=1' : ''}`);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      setData(await r.json()); setIdx({ best: 0, aggr: 0 }); setEdit({});
    } catch (e) { setErr((e as Error).message); }
  }, [game]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { fetch('/api/backtest').then((r) => r.json()).then(setBt).catch(() => setBt(null)); }, []);

  const ticket = (k: Kind): Ticket | undefined => edit[k] ?? data?.[k].options[idx[k] % Math.max(1, data[k].options.length)];
  const replace = (k: Kind, i: number) => {
    const t = ticket(k); if (!t || !data) return;
    const used = new Set(t.legs.map((l) => l.name)), now = Date.now();
    const alt = data.pool.filter((c) => c.pos === t.legs[i].pos && !used.has(c.name) && eligible(k, c, now))
      .sort((a, b) => (k === 'best' ? b.scored!.p - a.scored!.p : b.scored!.ev - a.scored!.ev))
      .find((c) => { try { makeTicket(t.legs.map((l, n) => (n === i ? c : l)), k); return true; } catch { return false; } });
    if (!alt) return alert('No eligible replacement for that position.');
    setEdit({ ...edit, [k]: makeTicket(t.legs.map((l, n) => (n === i ? alt : l)), k, { seed: 555 }) });
  };
  const save = async (k: Kind) => {
    const t = ticket(k); if (!t) return;
    const r = await fetch('/api/saved', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ kind: k, legs: t.legs, jointP: t.jointP, decimal: t.decimal }) });
    if (r.ok) setSaved((s) => s + 1);
  };

  return (
    <main className="mx-auto max-w-6xl space-y-3 p-3">
      <header className="flex flex-wrap items-center gap-2">
        <h1 className="text-xl font-bold">NFL Parlay <span className="text-neon">Lab</span></h1>
        {data && <span className={`rounded-full border px-2 py-0.5 text-xs ${data.mode === 'live' ? 'border-neon text-neon' : 'border-amber-400 text-amber-400'}`}>{data.mode === 'live' ? 'LIVE DATA' : 'DEMO DATA'}</span>}
      </header>
      <div className="flex flex-wrap gap-2">
        <select className="rounded-lg border border-line bg-card p-2" value={game} onChange={(e) => setGame(e.target.value)}>
          <option value="ALL">All games</option>{data?.games.map((g) => <option key={g.id} value={g.id}>{g.label}</option>)}
        </select>
        <button className="rounded-lg border border-line bg-card p-2" onClick={() => load(true)}>Refresh Data</button>
        <button className="rounded-lg border border-neon bg-emerald-950 p-2 font-semibold text-neon" onClick={() => load()}>Generate Both Tickets</button>
      </div>
      {err && <div className="rounded border border-red-500 p-2 text-sm text-red-400">Error: {err}</div>}
      {data && <div className="rounded border-l-4 border-amber-400 bg-amber-950/30 p-2 text-sm">
        {data.notes.map((n, i) => <div key={i}>{n}</div>)}
        <div>Scanned {data.scanned} props · {data.staleCount} with stale odds (over 30 min; over 60 min excluded from tickets).</div>
      </div>}
      <div className="grid gap-3 lg:grid-cols-2">{KINDS.map((k) => <TicketCard key={k} kind={k} t={ticket(k)} miss={data?.[k].missing ?? []} onRegen={() => { setEdit({ ...edit, [k]: undefined }); setIdx({ ...idx, [k]: idx[k] + 1 }); }} onReplace={(i) => replace(k, i)} onSave={() => save(k)} />)}</div>
      {ticket('best') && ticket('aggr') && <Compare a={ticket('best')!} b={ticket('aggr')!} />}
      <section className="rounded-xl border border-line bg-card p-3 text-sm">
        <b>Historical backtest</b> <span className="text-slate-400">(snapshots are logged before kickoff and settled from nflverse stats; ambiguous rows stay unsettled)</span>
        {!bt || bt.n === 0 ? <div className="text-slate-400">No settled snapshots yet. Run live mode through a full week, then reopen this page. No profitability claim is made.</div> :
          <div>Legs {bt.n}, hit rate {bt.legHitRate}%, single-leg ROI {bt.legRoiPct}%. Six-leg tickets: {bt.parlays.hits}/{bt.parlays.n}.
            <pre className="overflow-x-auto text-xs">{JSON.stringify({ byPosition: bt.byPosition, byMarket: bt.byMarket, calibration: bt.calibration }, null, 1)}</pre></div>}
      </section>
      <p className="text-xs text-slate-400">Saved this session: {saved}. Research tool only: no wagers are placed, no pick is guaranteed, and estimated payouts are products of leg odds, not FanDuel-confirmed prices.</p>
    </main>
  );
}

function TicketCard({ kind, t, miss, onRegen, onReplace, onSave }: { kind: Kind; t?: Ticket; miss: string[]; onRegen: () => void; onReplace: (i: number) => void; onSave: () => void }) {
  return (
    <section className="rounded-xl border border-line bg-card p-3">
      <b className="text-neon">{CONFIG[kind].label}</b>
      <div className="text-xs text-slate-400">{kind === 'best' ? 'Highest estimated joint probability' : 'Higher payout from supported legs only'}</div>
      {!t ? <div className="mt-2 text-red-400">Insufficient eligible data. Missing: {miss.join(', ') || 'unknown'}. No weak picks were added.</div> : <>
        {t.legs.map((l, i) => (
          <div key={l.id} className="mt-2 border-t border-line pt-2">
            <div className="flex justify-between"><div><span className="font-bold text-blue">{l.pos}</span> <b>{l.name}</b><div className="text-xs text-slate-400">{l.team} vs {l.opp} · {new Date(l.kickoff).toLocaleString()}</div></div><b>{fmtOdds(l.odds)}</b></div>
            <div className="text-sm">{label(l)}</div>
            <div className="text-xs text-slate-400">Proj {l.mean.toFixed(1)} · Hit <b className="text-neon">{pc(l.scored!.p)}</b> · Confidence {l.scored!.confidence} · n={l.sample}</div>
            <button className="mt-1 rounded border border-line px-2 py-1 text-sm" onClick={() => onReplace(i)}>Replace Player</button>
          </div>))}
        <div className="mt-3 grid grid-cols-3 gap-2 text-center">
          <div className="rounded bg-bg p-2"><b className="block text-lg">{fmtOdds(t.american)}</b>combined*</div>
          <div className="rounded bg-bg p-2"><b className="block text-lg text-neon">{pc(t.jointP, 2)}</b>joint prob</div>
          <div className="rounded bg-bg p-2"><b className={`block text-lg ${t.ev > 0 ? 'text-neon' : 'text-red-400'}`}>{pc(t.ev)}</b>EV</div>
        </div>
        <div className="mt-2 grid grid-cols-3 gap-2 text-center text-sm">{[5, 10, 20].map((s) => { const p = payout(s, t.decimal); return <div key={s} className="rounded bg-bg p-2">${s}<b className="block">+${p.profit.toFixed(2)}</b><span className="text-xs text-slate-400">${p.total.toFixed(2)} total</span></div>; })}</div>
        <div className="text-xs text-slate-400">*Estimated payout — not confirmed by FanDuel.</div>
        {t.warnings.length > 0 && <div className="mt-2 rounded border-l-4 border-amber-400 bg-amber-950/30 p-2 text-xs">{t.warnings.map((w, i) => <div key={i}>{w}</div>)}</div>}
        <div className="mt-2 flex gap-2"><button className="rounded border border-line p-2" onClick={onRegen}>Regenerate</button><button className="rounded border border-neon p-2 text-neon" onClick={onSave}>Save Ticket</button></div>
      </>}
    </section>
  );
}
function Compare({ a, b }: { a: Ticket; b: Ticket }) {
  const avg = (t: Ticket) => t.legs.reduce((s, l) => s + l.scored!.p, 0) / 6, min = (t: Ticket) => Math.min(...t.legs.map((l) => l.scored!.p));
  const shared = a.legs.filter((l) => b.legs.some((m) => m.name === l.name)).length;
  const rows: [string, string, string][] = [['Joint probability', pc(a.jointP, 2), pc(b.jointP, 2)], ['Product odds', `×${a.decimal.toFixed(1)}`, `×${b.decimal.toFixed(1)}`], ['$10 total return', `$${payout(10, a.decimal).total}`, `$${payout(10, b.decimal).total}`], ['Expected value', pc(a.ev), pc(b.ev)], ['Avg / min leg', `${pc(avg(a), 0)} / ${pc(min(a), 0)}`, `${pc(avg(b), 0)} / ${pc(min(b), 0)}`], ['Players shared', `${shared}`, `${shared}`]];
  return <section className="rounded-xl border border-line bg-card p-3 text-sm"><b>Comparison</b><table className="mt-1 w-full text-left"><thead><tr><th></th><th>Best</th><th>Aggressive</th></tr></thead><tbody>{rows.map((r) => <tr key={r[0]} className="border-t border-line"><td className="py-1">{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td></tr>)}</tbody></table></section>;
}
