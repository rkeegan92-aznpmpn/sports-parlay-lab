import './globals.css';
import type { Metadata, Viewport } from 'next';
export const metadata: Metadata = { title: 'NFL Parlay Lab', description: 'NFL player-prop research tool. Not betting advice.' };
export const viewport: Viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
