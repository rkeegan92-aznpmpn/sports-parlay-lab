# NFL Parlay Lab

Research tool that builds two six-leg player-prop tickets (1 QB, 2 RB, 2 WR, 1 TE) from FanDuel odds:
**Best Six** (highest estimated joint probability) and **Aggressive Six** (higher payout from supported legs only).
It never places wagers, never guarantees outcomes, and labels every payout "Estimated payout — not confirmed."

## API keys
| Key | Needed for | Where | Cost |
|---|---|---|---|
| `ODDS_API_KEY` | FanDuel player-prop odds | https://the-odds-api.com | Player-prop markets require a paid plan (check their pricing). Each event x market costs credits. |
| none | Stats and injuries (nflverse) | https://github.com/nflverse/nflverse-data | Free, open data |

Without `ODDS_API_KEY` the app runs in clearly labeled **Demo Data** mode (fictional players). If the live fetch fails, it falls back to demo and says why.

## Run locally
```bash
node -v            # needs >= 22.6
cp .env.example .env.local   # add ODDS_API_KEY
npm install
npm test           # 18 tests, node:test, no extra deps
npm run dev        # http://localhost:3000
```
Next.js loads `.env.local`. For tests-only use, no install is needed beyond Node.

## Deploy via GitHub
1. `git init && git add . && git commit -m "init" && git remote add origin <your repo> && git push -u origin main`
2. CI (`.github/workflows/ci.yml`) runs tests and typecheck on push.
3. Hosting: a Node host with a persistent disk (Render, Fly, Railway, a VPS) works with the bundled SQLite file. On Vercel/serverless the filesystem is ephemeral, so swap `src/server/db.ts` for a hosted SQLite/Postgres (e.g. Turso/libSQL); the schema is in that file. Set `ODDS_API_KEY` in the host's environment settings.

## Architecture
- `src/lib/odds.ts` American/decimal conversion, parlay product, payouts
- `src/lib/model.ts` probabilities: normal (yards), Poisson (counts, anytime TD), shrink toward market for small samples, injury haircut
- `src/lib/sim.ts` correlated joint probability (Gaussian copula; team 0.30 and game 0.12 loadings are assumptions)
- `src/lib/optimizer.ts` eligibility, validation, ticket builder; swap models by replacing `model.ts`/`sim.ts`
- `src/lib/providers/` The Odds API client, nflverse stats/injuries
- `src/lib/service.ts` live pipeline and demo data; `src/server/` SQLite, caching, snapshot logging
- `src/lib/backtest.ts`, `settle.ts` leakage-safe evaluation

## Backtesting
Each live refresh stores the last pre-kickoff snapshot per prop (the unique key and a kickoff check prevent later overwrites). `/api/backtest` settles finished props from nflverse stats, skipping ambiguous matches and pushes, and reports hit rate, ROI, calibration, and splits by position and market. No profitability claim is made, and results need a large sample.

## Known limits (verify before trusting)
- Written without network access: the nflverse URLs/column names and Odds API response shapes follow public docs but were **not tested against live endpoints**. Override URLs in `.env`; check `/api/health` and the notes banner.
- Not yet modeled: weather (Open-Meteo is the planned source), routes/target share, game script, home/away split, comparable-opponent history, alternate-line expansion beyond what FanDuel returns.
- Same-game parlay availability is never assumed; tickets are capped at 3 legs per game and flagged.
- `npm run typecheck` and `next build` have not been run here.
