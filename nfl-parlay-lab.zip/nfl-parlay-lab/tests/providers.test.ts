import test from 'node:test';
import assert from 'node:assert/strict';
import { fetchEvents, fetchEventProps, parseProps, OddsApiError } from '../src/lib/providers/oddsApi.ts';
import { parseCsv, toGames, project, oppFactor, normName } from '../src/lib/providers/stats.ts';
import { settle } from '../src/lib/settle.ts';
import { report } from '../src/lib/backtest.ts';

const resp = (status: number, body: unknown, bad = false) => async () => ({ ok: status < 400, status, headers: { get: () => '123' }, json: async () => { if (bad) throw new Error('x'); return body; } }) as unknown as Response;

test('Odds API errors map to OddsApiError', async () => {
  await assert.rejects(fetchEvents('k', resp(401, {})), (e: any) => e instanceof OddsApiError && e.status === 401 && /key/i.test(e.message));
  await assert.rejects(fetchEvents('k', resp(429, {})), (e: any) => e.status === 429);
  await assert.rejects(fetchEvents('k', resp(200, [], true)), /Malformed/);
  await assert.rejects(fetchEvents('k', resp(200, { no: 'array' })), /Unexpected/);
  await assert.rejects(fetchEvents('k', (async () => { throw new Error('offline'); }) as unknown as typeof fetch), (e: any) => e.status === 0);
  await assert.rejects(fetchEventProps('k', 'e1', ['player_pass_yds'], resp(422, {})), /plan/);
});
test('parseProps keeps FanDuel and drops malformed outcomes', () => {
  const rows = parseProps({ bookmakers: [
    { key: 'draftkings', markets: [{ key: 'player_pass_yds', outcomes: [{ name: 'Over', description: 'A', price: -110, point: 200 }] }] },
    { key: 'fanduel', last_update: 't', markets: [{ key: 'player_pass_yds', last_update: 't2', outcomes: [
      { name: 'Over', description: 'A B', price: -115, point: 250.5 }, { name: 'Under', description: 'A B', price: -105, point: 250.5 }, { name: 'Over', price: -110 }, { name: 'Over', description: 'C', price: 'x' } ] }] }] });
  assert.equal(rows.length, 2);
  assert.deepEqual(rows[0], { player: 'A B', market: 'player_pass_yds', side: 'Over', line: 250.5, odds: -115, updatedAt: 't2' });
  assert.deepEqual(parseProps({}), []);
});
test('CSV parsing, projection and opponent factor', () => {
  const csv = 'player_display_name,position,team,opponent_team,season,week,season_type,rushing_yards\n"Smith, Jr.",RB,AAA,BBB,2026,1,REG,80\nJoe Doe,RB,AAA,CCC,2026,2,REG,40\nJoe Doe,RB,AAA,BBB,2026,3,REG,120\n';
  const g = toGames(parseCsv(csv));
  assert.equal(g.length, 3); assert.equal(g[0].name, 'Smith, Jr.');
  const p = project(g, 'player_rush_yds')!;
  assert.equal(p.sample, 3); assert.ok(p.mean > 60 && p.mean < 100);
  assert.equal(project([], 'player_rush_yds'), null);
  const f = oppFactor(g, 'BBB', 'RB', 'player_rush_yds');
  assert.ok(f > 1 && f <= 1.15);
  assert.equal(normName('Patrick Mahomes II'), 'patrick mahomes');
});
test('settlement refuses ambiguous matches and pushes', () => {
  const g = toGames(parseCsv('player_display_name,position,team,opponent_team,season,week,rushing_yards\nA B,RB,X,Y,2026,1,70\nA B,RB,X,Y,2026,9,30\nC D,RB,X,Z,2026,2,50\n'));
  assert.equal(settle({ player: 'A B', opp: 'Y', market: 'player_rush_yds', side: 'Over', line: 60.5 }, g), null);
  assert.equal(settle({ player: 'C D', opp: 'Z', market: 'player_rush_yds', side: 'Over', line: 49.5 }, g), 1);
  assert.equal(settle({ player: 'C D', opp: 'Z', market: 'player_rush_yds', side: 'Under', line: 49.5 }, g), 0);
  assert.equal(settle({ player: 'C D', opp: 'Z', market: 'player_rush_yds', side: 'Over', line: 50 }, g), null);
});
test('backtest rejects leaked rows and computes metrics', () => {
  const row = (hit: 0 | 1, snap: number, ko: number, extra = {}) => ({ pos: 'QB', market: 'player_pass_yds', side: 'Over', line: 1, odds: 100, p: 0.6, hit, snapshotTs: snap, kickoffTs: ko, ...extra });
  const r = report([row(1, 1, 2), row(0, 1, 2), row(1, 2, 2), row(1, 3, 2)]);
  assert.equal(r.n, 2); assert.equal(r.rejected, 2); assert.equal(r.legHitRate, 50); assert.equal(r.legRoiPct, 0);
  const t = [1, 2, 3, 4, 5, 6].map((i) => row(1, 1, 2, { ticketId: 't1', pos: i === 1 ? 'QB' : 'RB' }));
  const r2 = report(t);
  assert.deepEqual(r2.parlays, { n: 1, hits: 1, roiPct: 6300 });
  assert.equal(report([]).legHitRate, null);
});
