import test from 'node:test';
import assert from 'node:assert/strict';
import { americanToDecimal, decimalToAmerican, parlayDecimal, payout, impliedProb } from '../src/lib/odds.ts';

test('American to decimal conversion', () => {
  assert.equal(americanToDecimal(100), 2);
  assert.equal(americanToDecimal(150), 2.5);
  assert.ok(Math.abs(americanToDecimal(-110) - 1.90909) < 1e-4);
  assert.equal(americanToDecimal(-200), 1.5);
});
test('round trip and implied probability', () => {
  assert.equal(decimalToAmerican(2.5), 150);
  assert.equal(decimalToAmerican(1.5), -200);
  assert.ok(Math.abs(impliedProb(-110) - 0.5238) < 1e-3);
});
test('invalid odds throw', () => {
  for (const bad of [0, 50, -50, NaN, Infinity]) assert.throws(() => americanToDecimal(bad), RangeError);
  assert.throws(() => decimalToAmerican(1), RangeError);
});
test('parlay product and payout', () => {
  assert.equal(parlayDecimal([100, 100, 100]), 8);
  assert.deepEqual(payout(10, 8), { profit: 70, total: 80 });
  assert.deepEqual(payout(5, 1.90909), { profit: 4.55, total: 9.55 });
});
