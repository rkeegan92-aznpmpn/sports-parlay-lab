import test from 'node:test';
import assert from 'node:assert/strict';
import { poissonCdf, rawProbability, scoreAll, scoreCandidate } from '../src/lib/model.ts';
import { simulate } from '../src/lib/sim.ts';
import { build, generate, validateLegs, makeTicket, eligible } from '../src/lib/optimizer.ts';
import { demoResult } from '../src/lib/service.ts';
import type { Candidate } from '../src/lib/types.ts';

const NOW = Date.parse('2026-11-08T12:00:00Z');
const demo = () => demoResult(NOW).candidates;
const pick = (ids: string[]) => ids.map((i) => demo().find((c) => c.id === i)!);

test('poisson and normal sanity', () => {
  assert.ok(Math.abs(poissonCdf(0, 1) - Math.exp(-1)) < 1e-9);
  const over = rawProbability({ market: 'player_rush_yds', side: 'Over', line: 50, mean: 50, sd: 20 });
  assert.ok(Math.abs(over - 0.5) < 0.01);
  const u = rawProbability({ market: 'player_rush_yds', side: 'Under', line: 50, mean: 50, sd: 20 });
  assert.ok(Math.abs(over + u - 1) < 1e-9);
});
test('small samples shrink toward market; injury lowers probability', () => {
  const base = demo().find((c) => c.id === 'q1')!;
  const small = scoreCandidate({ ...base, sample: 1 }, NOW), big = scoreCandidate({ ...base, sample: 40 }, NOW);
  assert.ok(Math.abs(small.p - 0.5336) < Math.abs(big.p - 0.5336) + 0.2 && small.weight < big.weight);
  assert.ok(scoreCandidate({ ...base, injury: 'Questionable' }, NOW).p < big.p + 1e-9);
  assert.equal(scoreCandidate({ ...base, injury: 'Out' }, NOW).p, 0);
});
test('stale odds are flagged and excluded', () => {
  const c = demo().find((x) => x.id === 'q3')!;
  assert.equal(c.scored!.stale, true);
  assert.equal(eligible('best', c, NOW), false);
  assert.equal(eligible('aggr', c, NOW), false);
});
test('correlated legs raise joint probability above the independent product', () => {
  const mk = (id: string, team: string): Candidate => ({ ...demo()[0], id, team, scored: { ...demo()[0].scored!, p: 0.5 } });
  const legs = [mk('a', 'X'), mk('b', 'X')];
  const corr = simulate(legs, { n: 40000, seed: 7, teamLoad: 0.8, gameLoad: 0.1 }).jointP;
  const indep = simulate(legs, { n: 40000, seed: 7, teamLoad: 0.001, gameLoad: 0.001 }).jointP;
  assert.ok(Math.abs(indep - 0.25) < 0.02);
  assert.ok(corr > indep + 0.05, `${corr} vs ${indep}`);
});
test('exact six-position composition and no duplicates in generated tickets', () => {
  const g = generate(demo(), NOW);
  for (const k of ['best', 'aggr'] as const) {
    assert.ok(g[k].options.length > 0, `${k} produced no options`);
    for (const t of g[k].options) {
      assert.deepEqual(validateLegs(t.legs), []);
      const c = (p: string) => t.legs.filter((l) => l.pos === p).length;
      assert.deepEqual([c('QB'), c('RB'), c('WR'), c('TE')], [1, 2, 2, 1]);
      assert.equal(new Set(t.legs.map((l) => l.name)).size, 6);
      assert.ok(t.jointP >= 0 && t.jointP <= 1);
    }
  }
});
test('Best ranks by joint probability; Aggressive pays more', () => {
  const g = generate(demo(), NOW);
  assert.ok(g.best.options[0].jointP >= g.aggr.options[0].jointP - 0.005);
  assert.ok(g.aggr.options[0].decimal >= g.best.options[0].decimal);
});
test('invalid combinations rejected', () => {
  assert.ok(validateLegs(pick(['q1', 'r1', 'r2', 'w1', 'w2'])).length > 0, 'five legs');
  assert.ok(validateLegs(pick(['q1', 'r1', 'r2', 'r4', 'w1', 'w2'])).some((e) => e.includes('RB')), 'three RBs');
  const dup = pick(['q1', 'r1', 'r1', 'w1', 'w2', 't1']);
  assert.ok(validateLegs(dup).includes('Duplicate player'));
  assert.throws(() => makeTicket(dup, 'best'), /Invalid ticket/);
  assert.ok(validateLegs(pick(['q1', 'r1', 'r3', 'w1', 'w3', 't1'])).some((e) => e.includes('game')), 'four legs in one game');
});
test('missing data reports missing positions instead of padding', () => {
  const noTE = demo().filter((c) => c.pos !== 'TE');
  const r = build('best', noTE, { now: NOW });
  assert.equal(r.options.length, 0);
  assert.ok(r.missing.some((m) => m.includes('TE')));
  assert.equal(build('aggr', [], { now: NOW }).options.length, 0);
});
test('same-game warning and demo label present', () => {
  const t = generate(demo(), NOW).best.options[0];
  assert.ok(t.warnings.some((w) => w.includes('Demo Data')));
});
